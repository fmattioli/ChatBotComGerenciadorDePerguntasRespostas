﻿namespace Bot.Dominio.Entidades
{
    public class Intencao
    {
        public string Id { get; set; }
        public string IntencaoTexto { get; set; }
    }
}
