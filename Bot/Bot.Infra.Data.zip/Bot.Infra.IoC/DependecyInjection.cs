﻿using Bot.Aplicacao.Interfaces;
using Bot.Aplicacao.Servicos;
using Bot.Dominio.Interfaces;
using Bot.Infra.Data.Config;
using Bot.Infra.Data.Repositorio;
using Microsoft.Extensions.DependencyInjection;

namespace Bot.Infra.IoC
{
    public static class DependecyInjection
    {
        public static IServiceCollection AdicionarInfraEstruturaBot(this IServiceCollection services)
        {
            //Add injeção de classes
            services.AddSingleton<IComumServico, ComumServico>();
            services.AddSingleton<DbSession>();
            services.AddSingleton<ICardsServico, CardsServico>();
            services.AddSingleton<ICardsRepositorio, CardsRepositorio>();
            services.AddSingleton<IIntencoesServico, IntencoesServico>();
            services.AddSingleton<IIntencoesRepositorio, IntencoesRepositorio>();

            return services;
        }


        public static IServiceCollection AdicionarInfraEstruturaGerenciador(this IServiceCollection services)
        {
            //Add injeção de classes
            services.AddScoped<DbSession>();
            services.AddScoped<IUsuarioServico, UsuarioServico>();
            services.AddScoped<IEspecialidadeServico, EspecialidadeServico>();
            services.AddScoped<IEspecialidadeRepositorio, EspecialidadeRepositorio>();

            return services;
        }
    }


}
