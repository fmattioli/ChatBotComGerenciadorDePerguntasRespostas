﻿using Bot.Aplicacao.Interfaces;
using Bot.Aplicacao.ViewModels;
using Bot.Web.Cards.Gerenciador;
using Bot.Web.CognitiveModels;
using Bot.Web.Dialogs.Comum;
using Bot.Web.Recognizers;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Bot.Web.Dialogs.RegistroImoveis
{
    public class RegistroImoveisDialog : CancelAndHelpDialog
    {
        private readonly GerenciarCards _gerenciadorCards;
        private readonly RegistroImoveisRecognizer _luisRecognizer;
        private readonly IComumServico _comumServico;
        private readonly ICardsServico _cardsServico;
        private readonly IIntencoesServico _intencoesServico;

        public RegistroImoveisDialog(GerenciarCards gerenciadorCards, RegistroImoveisRecognizer luisRecognizer, IComumServico comumServico, ICardsServico cardsServico, IIntencoesServico intencoesServico)
           : base(nameof(RegistroImoveisDialog))
        {
            _luisRecognizer = luisRecognizer;
            _gerenciadorCards = gerenciadorCards;
            _comumServico = comumServico;
            _cardsServico = cardsServico;
            _intencoesServico = intencoesServico;

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                ExibirOpcoesRegistroImoveis,
                ObterIntencaoUsuario
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> ExibirOpcoesRegistroImoveis(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            //Mensagem em caso de compreensão da mensagem enviado ao Bot (Card ou Mensagem).
            if (stepContext.Options is List<string> && !None)
            {
                foreach (var resposta in (IList<string>)stepContext.Options)
                    await DialogoComum.EnviarMensagem(stepContext, cancellationToken, $"{resposta}");

                var mensagemContinuarConversa = "Fique a vontade para me perguntar outras coisas...";
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text(mensagemContinuarConversa, mensagemContinuarConversa, InputHints.ExpectingInput) }, cancellationToken);
            }

            //Mensagem em caso de não compreensão por parte do Bot.
            if (stepContext.Options is string && None)
            {
                await DialogoComum.EnviarMensagem(stepContext, cancellationToken, $"{stepContext.Options} \U0001F600");
                await DialogoComum.EnviarMensagem(stepContext, cancellationToken, "Vamos tentar novamente? Navegue entre os menus ou me envie uma mensagem.");
                return await stepContext.PromptAsync(nameof(TextPrompt), _gerenciadorCards.RetornarAdaptiveCard(await _cardsServico.ObterCards()), cancellationToken);
            }

            //Mensagem de inicio da conversa.
            CartorioViewModel cartorio = stepContext.Options as CartorioViewModel;
            await DialogoComum.EnviarMensagem(stepContext, cancellationToken, $"Olá!!! Seja bem vindo, sou o assistente virtual do: {cartorio.Nome}!");
            await DialogoComum.EnviarMensagem(stepContext, cancellationToken, "Fique a vontade para navegar entre os menus! \U0001F600");
            await DialogoComum.EnviarMensagem(stepContext, cancellationToken, "Caso queira, você pode me enviar uma mensagem, por exemplo: **Como registrar um título?** \U0001F600");
            return await stepContext.PromptAsync(nameof(TextPrompt), _gerenciadorCards.RetornarAdaptiveCard(await _cardsServico.ObterCards()), cancellationToken);
        }

        private async Task<DialogTurnResult> ObterIntencaoUsuario(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            IList<string> respostas;
            if (await _comumServico.IsJson(stepContext.Result?.ToString()))
            {
                var intencaoViewModel = await _comumServico.DesserializarClasse(stepContext.Result.ToString());
                respostas = await _intencoesServico.ObterRespostaIntencaoCard(intencaoViewModel.Intencao);
                return await stepContext.ReplaceDialogAsync(InitialDialogId, respostas, cancellationToken);

            }

            var luisResult = await _luisRecognizer.RecognizeAsync<RegistroImoveisCognitiveModel>(stepContext.Context, cancellationToken);
            if (luisResult.Intencao.Contains("None"))
                return await stepContext.ReplaceDialogAsync(InitialDialogId, "Desculpa, não entendi o que você quis dizer...", cancellationToken);

            return await stepContext.ReplaceDialogAsync(InitialDialogId, await _intencoesServico.ObterRespostaIntencaoLUIS(luisResult.Intencao), cancellationToken);
        }
    }
}
