﻿function adicionarEspecialidade() {

    if ($('#especialidade').val() === undefined || $('#descricao').val() === "") {
        $('#especialidade').focus();
        $('#descricao').focus();
        return;
    }

    $.ajax({
        url: "/Especialidades/AdicionarEspecialidade/",
        type: "POST",
        dataType: "json",
        data: JSON.stringify({
            Nome: $('#especialidade').val(),
            Descricao: $('#descricao').val()
        }),
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            if (response.msgErro === "") {
                M.toast({
                    html: "Especialidade inserida com sucesso!",
                    classes: 'black darken-4 rounded',
                });

                $('#especialidadesGrid tbody').html(response.htmlGrid);
                $('#especialidadeForm').trigger("reset");
                return;
            }

            M.toast({
                html: response.msgErro,
                classes: 'black darken-4 rounded',
            });

        },
        error: function (xhr, textStatus, errorThrown) {
            montarAlertaPadrao($(xhr.responseText).filter('title').get(0).text, false, "alertaGestaoDeDados");
        }
    });
}


function excluirEspecialidade(EspecialdiadeId) {

    $('.modal').modal({
        dismissble: true
    });
    $('#modal').modal('open');
    $("#texto").text("Deseja realmente excluir esta especialidade?");
    $("#nome").text("Ao excluir uma especialidade, todas a configuração vinculada a ela será apagada, não é possível reverter esta ação!");
    $(".btnExcluir").on('click', function () {
        $.ajax({
            method: "POST",
            url: "/Veiculos/Delete",
            data: { id: id },
            success: function (data) {
                location.reload(true);
            }
        })
    })

}



