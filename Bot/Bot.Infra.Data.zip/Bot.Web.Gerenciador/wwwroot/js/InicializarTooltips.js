﻿$(document).ready(function () {
    $(".tooltip").tooltip();
})
