﻿$(document).ready(function () {
    $(".dropdown-trigger").dropdown();
})


// Or with jQuery
$(document).ready(function () {
    $('select').formSelect();
});