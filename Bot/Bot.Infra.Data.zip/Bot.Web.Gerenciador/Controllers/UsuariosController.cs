﻿using Bot.Aplicacao.Interfaces;
using Bot.Aplicacao.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Bot.Web.Gerenciador.Controllers
{
    public class UsuariosController : Controller
    {
        
        public IActionResult Login()
        {
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<IActionResult> Login(UsuarioViewModel usuario, [FromServices] IUsuarioServico usuarioServico)
        {
            if (ModelState.IsValid && await usuarioServico.Existe(usuario))
                return RedirectToAction("Index", "Home");

            ModelState.AddModelError("", "Usuario e/ou senha inválidas");
            return View(usuario);
        }
    }
}
