﻿using Bot.Dominio.Entidades;
using Bot.Dominio.Interfaces;
using Bot.Infra.Data.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Infra.Data.Repositorio
{
    public class CardsRepositorio : BaseRepositorio<Cards>, ICardsRepositorio
    {
        public CardsRepositorio(DbSession dbSession) : base(dbSession)
        {

        }
    }
}
