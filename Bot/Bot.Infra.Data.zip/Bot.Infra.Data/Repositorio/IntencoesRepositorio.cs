﻿using Bot.Dominio.Entidades;
using Bot.Dominio.Interfaces;
using Bot.Infra.Data.Config;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Infra.Data.Repositorio
{
    public class IntencoesRepositorio : BaseRepositorio<Intencao>, IIntencoesRepositorio
    {
        public IntencoesRepositorio(DbSession dbSession) : base(dbSession)
        {

        }

        public async Task<IList<string>> ObterRespostasIntencaoCard(string Intencao)
        {
            await VerificarStatusBancoDeDados("Data Source=agarni.ddns.net,7789;Initial Catalog=Bot;Integrated Security=false;User Id=Bot;Password=bot@123;Connection Timeout=30;");
            SQL.Clear();
            SQL.AppendLine("SELECT");
            SQL.AppendLine("Resposta");
            SQL.AppendLine("FROM Bot.CardsRetorno CardsRetorno");
            SQL.AppendLine("INNER JOIN Bot.RespostasCard RespostasCard ON CardsRetorno.Id = RespostasCard.CardsRetornoId");
            SQL.AppendLine($"WHERE IntencaoCard = '{Intencao}'");

            using (var conn = _db.Connection)
            {
                var retorno = (await conn.QueryAsync<string>(SQL.ToString())).ToList();
                return retorno;
            }
        }

        public async Task<IList<string>> ObterRespostasIntencaoLUIS(string Intencao)
        {
            await VerificarStatusBancoDeDados("Data Source=agarni.ddns.net,7789;Initial Catalog=Bot;Integrated Security=false;User Id=Bot;Password=bot@123;Connection Timeout=30;");
            SQL.Clear();
            SQL.AppendLine("SELECT");
            SQL.AppendLine("Respostas.[Resposta]");
            SQL.AppendLine("FROM Bot.Intencoes Intencoes");
            SQL.AppendLine("INNER JOIN Bot.Perguntas Perguntas ON Intencoes.Id = Perguntas.[IntencaoId]");
            SQL.AppendLine("INNER JOIN Bot.Respostas Respostas ON Perguntas.Id = Respostas.PerguntaId");
            SQL.AppendLine($"WHERE Intencao = '{Intencao}'");

            using (var conn = _db.Connection)
            {
                var retorno = (await conn.QueryAsync<string>(SQL.ToString())).ToList();
                return retorno;
            }
        }
    }
}
