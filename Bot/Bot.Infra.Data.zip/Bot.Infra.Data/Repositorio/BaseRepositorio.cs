﻿using Bot.Dominio.Entidades;
using Bot.Dominio.Interfaces;
using Bot.Infra.Data.Config;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Infra.Data.Repositorio
{
    public class BaseRepositorio<T> : IBaseRepositorio<T> where T : class
    {
        protected readonly DbSession _db;
        public StringBuilder SQL { get; set; } = new StringBuilder();
        public BaseRepositorio(DbSession _db)
        {
            this._db = _db;
        }
        public async Task<Retorno> Adicionar(T entidade, string Tabela)
        {
            var retorno = new Retorno();
            try
            {
                await Task.Run(() =>
                {
                    SQL.Clear();
                    var prop = entidade.GetType().GetProperties();
                    prop = prop.Where(a => a.Name != "Id").ToArray();
                    string lastItem = prop[prop.Length - 1].Name;

                    SQL.AppendLine($"INSERT INTO Bot.{Tabela}");
                    SQL.AppendLine($"(");

                    foreach (var item in prop)
                    {
                        if (item.Name != lastItem)
                            SQL.AppendLine($"{item.Name},");
                        else
                            SQL.AppendLine($"{item.Name}");
                    }

                    SQL.AppendLine($")");
                    SQL.AppendLine($"VALUES");
                    SQL.AppendLine($"(");

                    foreach (var item in prop)
                    {
                        if (item.Name != lastItem)
                        {
                            if (item.PropertyType.FullName.Contains("String") || item.PropertyType.FullName.Contains("DateTime") || item.PropertyType.FullName.Contains("Boolean"))
                                SQL.AppendLine($"'{item.GetValue(entidade)}',");
                            else
                                SQL.AppendLine($"{item.GetValue(entidade).ToString().Replace(",", ".")},");
                        }
                        else
                        {
                            if (item.PropertyType.FullName.Contains("String") || item.PropertyType.FullName.Contains("DateTime") || item.PropertyType.FullName.Contains("Boolean"))
                                SQL.AppendLine($"'{item.GetValue(entidade)}'");
                            else
                                SQL.AppendLine($"{item.GetValue(entidade).ToString().Replace(",", ".")}");
                        }
                    }

                    SQL.AppendLine($")");

                });

                await VerificarStatusBancoDeDados("Data Source=agarni.ddns.net,7789;Initial Catalog=Bot;Integrated Security=false;User Id=Bot;Password=bot@123;Connection Timeout=30;");
                using (var conn = _db.Connection)
                {
                    if(await conn.ExecuteAsync(SQL.ToString()) >= 1)
                    {
                        retorno.Sucesso = true;
                        retorno.MensagemErro = "";
                        return retorno;
                    }

                    retorno.Sucesso = false;
                    retorno.MensagemErro = "Erro ao inserir dados. 0 linhas afetadas";
                    return retorno;
                }
            }
            catch (Exception e)
            {
                retorno.Sucesso = false;
                retorno.MensagemErro = e.Message;
                return retorno;
            }
        }

        public async Task<Retorno> Excluir(Guid Id, string Tabela)
        {
            var retorno = new Retorno();
            try
            {
                retorno.Sucesso = true;
                retorno.MensagemErro = "";
                return retorno;
            }
            catch (Exception e)
            {
                retorno.Sucesso = false;
                retorno.MensagemErro = e.Message;
                return retorno;
            }
        }

        public async Task<IList<T>> ObterTodos(string Tabela)
        {
            await VerificarStatusBancoDeDados("Data Source=agarni.ddns.net,7789;Initial Catalog=Bot;Integrated Security=false;User Id=Bot;Password=bot@123;Connection Timeout=30;");
            using (var conn = _db.Connection)
            {
                SQL.Clear();
                SQL.AppendLine($"SELECT * FROM Bot.{Tabela}");
                var retorno = (await conn.QueryAsync<T>(SQL.ToString())).ToList();
                return retorno;
            }
        }

        public async Task<T> ObterPorId(string Id)
        {
            await VerificarStatusBancoDeDados("Data Source=agarni.ddns.net,7789;Initial Catalog=Bot;Integrated Security=false;User Id=Bot;Password=bot@123;Connection Timeout=30;");
            var tipo = typeof(T);
            SQL.Clear();
            SQL.AppendLine($"SELECT * FROM Bot.{tipo.Name} Where Id = {Id}");

            using (var conn = _db.Connection)
            {
                var retorno = await conn.QueryFirstOrDefaultAsync<T>(SQL.ToString());
                return retorno;
            }
        }

        public async Task VerificarStatusBancoDeDados(string ConectionString)
        {
            await Task.Run(() =>
            {
                if (_db.Connection.State != System.Data.ConnectionState.Open)
                {
                    _db.Connection = new SqlConnection("Data Source=agarni.ddns.net,7789;Initial Catalog=Bot;Integrated Security=false;User Id=Bot;Password=bot@123;Connection Timeout=30;");
                    _db.Connection.Open();
                }
            });
        }

    }
}
