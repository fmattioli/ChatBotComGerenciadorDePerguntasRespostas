﻿using Bot.Dominio.Entidades;
using Bot.Dominio.Interfaces;
using Bot.Infra.Data.Config;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Infra.Data.Repositorio
{
    public class EspecialidadeRepositorio : BaseRepositorio<Especialidade>, IEspecialidadeRepositorio
    {
        private readonly DbSession _db;
        public EspecialidadeRepositorio(DbSession dbSession) : base(dbSession)
        {
            _db = dbSession;
        }

        public async Task<Especialidade> ObterEspecialidadePorNome(string Nome)
        {

            SQL.Clear();
            SQL.AppendLine($"SELECT * FROM Bot.Especialidade Where Nome = '{Nome}'");

            using (var conn = _db.Connection)
            {
                var retorno = await conn.QueryFirstOrDefaultAsync<Especialidade>(SQL.ToString());
                return retorno;
            }
        }

        public async Task<string> ObterLUISAPIKey(string Nome)
        {
            SQL.Clear();
            SQL.AppendLine($"SELECT LuisAPIKey FROM Bot.Especialidade Where Especialidade = '{Nome}'");

            using (var conn = _db.Connection)
            {
                var retorno = await conn.QueryFirstOrDefaultAsync<string>(SQL.ToString());
                return retorno;
            }
        }
    }
}
