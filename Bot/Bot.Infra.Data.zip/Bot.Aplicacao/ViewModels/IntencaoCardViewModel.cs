﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Aplicacao.ViewModels
{
    public class IntencaoCardViewModel
    {
        public string Intencao { get; set; }
    }
}
