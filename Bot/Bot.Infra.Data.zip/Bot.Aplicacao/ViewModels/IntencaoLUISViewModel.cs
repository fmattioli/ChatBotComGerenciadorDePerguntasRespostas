﻿namespace Bot.Aplicacao.ViewModels
{
    public class IntencaoLUISViewModel
    {
        public string Id { get; set; }
        public string Intencao { get; set; }
    }
}
