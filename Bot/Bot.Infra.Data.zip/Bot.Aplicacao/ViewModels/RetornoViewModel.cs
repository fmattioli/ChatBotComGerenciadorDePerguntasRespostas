﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Aplicacao.ViewModels
{
    public class RetornoViewModel
    {
        public bool Sucesso { get; set; }
        public string MensagemErro { get; set; }
        public string Resultado { get; set; }
    }
}
