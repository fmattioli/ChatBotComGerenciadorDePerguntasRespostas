﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Aplicacao.ViewModels
{
    public class UsuarioViewModel
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        [Required(ErrorMessage = "Digite um e-mail")]
        [EmailAddress(ErrorMessage = "Informe um e-mail válido")]
        public string Email { get; set; }
        [MinLength(10, ErrorMessage = "Digite uma senha maior que 10 caracteres")]
        [Required(ErrorMessage = "Digite uma senha")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }
    }
}
