﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Aplicacao.ViewModels
{
    public class CartorioViewModel
    {
        public EspecialidadeCartorio Especialidade { get; set; }
        public string Nome { get; set; }
        public string Site { get; set; }
    }

    public static class CartorioPropriedades
    {
        public static EspecialidadeCartorio Especialidade { get; set; }
        public static string Nome { get; set; }
        public static string Site { get; set; }
    }

    public enum EspecialidadeCartorio
    {
        RegistroImoveis = 1,
        Protesto = 2

    }
}
