﻿using Bot.Aplicacao.Interfaces;
using Bot.Aplicacao.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Aplicacao.Servicos
{
    public class ComumServico : UtilitarioServico<IntencaoCardViewModel>, IComumServico
    {
    }
}
