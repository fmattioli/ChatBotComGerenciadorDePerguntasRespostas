﻿using Bot.Aplicacao.Interfaces;
using Bot.Aplicacao.ViewModels;
using Bot.Dominio.Interfaces;
using Bot.Dominio.Entidades;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bot.Aplicacao.Servicos
{
    public class IntencoesServico : IIntencoesServico
    {
        private readonly IIntencoesRepositorio intencoesRepositorio;
        public IntencoesServico(IIntencoesRepositorio perguntaRepositorio)
        {
            this.intencoesRepositorio = perguntaRepositorio;
        }

        public async Task<RetornoViewModel> Adicionar(IntencaoLUISViewModel intencoesViewModel)
        {
            var pergunta = new Intencao
            {
                IntencaoTexto = intencoesViewModel.Intencao
            };

            var retorno = await intencoesRepositorio.Adicionar(pergunta, "Intencoes");
            return new RetornoViewModel
            {
                MensagemErro = retorno.MensagemErro,
                Sucesso = retorno.Sucesso
            };
        }

        public async Task<IList<string>> ObterRespostaIntencaoLUIS(string Intencao)
        {
            var respostas = new List<string>();
            foreach (var item in await intencoesRepositorio.ObterRespostasIntencaoLUIS(Intencao))
                respostas.Add(item);
            return respostas;
        }


        public async Task<IList<string>> ObterRespostaIntencaoCard(string Intencao)
        {var respostas = new List<string>();
            foreach (var item in await intencoesRepositorio.ObterRespostasIntencaoCard(Intencao))
                respostas.Add(item);
            return respostas;
        }



    }
}
