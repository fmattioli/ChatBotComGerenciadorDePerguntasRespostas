﻿using Bot.Aplicacao.Interfaces;
using Bot.Aplicacao.ViewModels;
using Bot.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bot.Dominio.Entidades;


namespace Bot.Aplicacao.Servicos
{
    public class EspecialidadeServico : IEspecialidadeServico
    {
        private readonly IEspecialidadeRepositorio especialidadeRepositorio;
        public EspecialidadeServico(IEspecialidadeRepositorio especialidadeRepositorio)
        {
            this.especialidadeRepositorio = especialidadeRepositorio;
        }

        public async Task<RetornoViewModel> Adicionar(EspecialidadeViewModel especialidadeViewModel)
        {
            var especialidade = new Especialidade()
            {
                Descricao = especialidadeViewModel.Descricao,
                Nome = especialidadeViewModel.Nome
            };

            var retorno = await especialidadeRepositorio.Adicionar(especialidade, "Especialidades");

            return new RetornoViewModel
            {
                MensagemErro = retorno.MensagemErro,
                Sucesso = retorno.Sucesso,
                Resultado = await MontarHtmlGrid()
            };
        }

        public async Task<RetornoViewModel> Excluir(EspecialidadeViewModel especialidadeViewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<string> MontarHtmlGrid()
        {
            var builder = new StringBuilder();
            foreach (var item in await ObterEspecialidades())
            {
                builder.AppendLine("<tr>");
                builder.AppendLine("<td>");
                builder.AppendLine($"{item.Nome}");
                builder.AppendLine("</td>");
                builder.AppendLine("<td>");
                builder.AppendLine($"{item.Descricao}");
                builder.AppendLine("</td>");
                builder.AppendLine("<td>");
                builder.AppendLine("<a class=\"btn-floating btn-large waves-effect waves-light red\"><i class=\"material-icons\">delete</i></a>");
                builder.AppendLine("</td>");
                builder.AppendLine("</tr>");
            }
            return builder.ToString();
        }

        public async Task<EspecialidadeViewModel> ObterEspecialidadePorId(string Id)
        {
            var retorno = await especialidadeRepositorio.ObterPorId(Id);
            return new EspecialidadeViewModel
            {
                Nome = retorno.Nome
            };

        }

        public async Task<EspecialidadeViewModel> ObterEspecialidadePorNome(string Nome)
        {
            var retorno = await especialidadeRepositorio.ObterEspecialidadePorNome(Nome);
            return new EspecialidadeViewModel
            {
                Nome = retorno.Nome
            };
        }

        public async Task<IList<EspecialidadeViewModel>> ObterEspecialidades()
        {
            var especialidades = new List<EspecialidadeViewModel>();
            foreach (var item in await especialidadeRepositorio.ObterTodos("Especialidades"))
                especialidades.Add(new EspecialidadeViewModel
                {
                    Id = item.Id,
                    Descricao = item.Descricao,
                    Nome = item.Nome
                });

            return especialidades;
        }


    }
}
